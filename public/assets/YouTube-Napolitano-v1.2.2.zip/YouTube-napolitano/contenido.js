(() => {
  'use strict';
  if (window.__napolitanoLoaded) return;
  window.__napolitanoLoaded = true;
  const root = document.documentElement;
  for (const [key, file] of [['lace','encaje'], ['logo','logo'], ['heart','corazon'], ['bow','lazo']]) {
    root.style.setProperty(`--np-${key}`, `url("${chrome.runtime.getURL(`imagenes/${file}.svg`)}")`);
  }
  const mediaSelector = [
    'ytd-thumbnail', 'yt-thumbnail-view-model', '.ytThumbnailViewModelHost',
    '.yt-lockup-view-model__content-image',
    '.shortsLockupViewModelHostThumbnailContainer',
    '.shortsLockupViewModelHostThumbnail',
    'ytd-reel-item-renderer #thumbnail'
  ].join(',');
  const commentSelector = 'ytd-comment-view-model, ytd-comment-renderer';
  const playerSelector = 'ytd-reel-video-renderer .html5-video-player, ytd-shorts .html5-video-player';
  const shortsImages = 'ytm-shorts-lockup-view-model img, ytd-reel-item-renderer img';
  const cardSelector = 'ytd-rich-item-renderer, ytd-rich-grid-media, ytd-grid-video-renderer, ytd-browse yt-lockup-view-model, ytd-browse ytd-video-renderer';
  const selector = [cardSelector, mediaSelector, commentSelector, playerSelector, shortsImages].join(',');
  let enabled = true;
  function cardHost(el) {
    const host = el.closest('ytd-rich-item-renderer') || el.closest('ytd-rich-grid-media') || el.closest('ytd-grid-video-renderer') || el.closest('ytd-video-renderer') || el.closest('yt-lockup-view-model');
    if (!host || (!host.closest('ytd-browse') && !host.matches('ytd-rich-item-renderer,ytd-rich-grid-media,ytd-grid-video-renderer'))) return null;
    if (host.querySelector('ytm-shorts-lockup-view-model,ytd-reel-item-renderer,ytd-rich-section-renderer')) return null;
    if (!host.querySelector(mediaSelector+',ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,a[href*="/watch"],a[href*="/playlist"]')) return null;
    return host;
  }
  function decorateCard(el) {
    const host=cardHost(el);
    if (!host) return;
    frameHost(host,'card');
    // Remove image-only frames when an asynchronously loaded card becomes available.
    for (const old of host.querySelectorAll('.np-media > .np-lace-frame')) old.remove();
  }
  function frameHost(host, kind) {
    if (!host || host.closest('.np-lace-frame')) return;
    // Frame only the deepest image wrapper. Never decorate a title link.
    if (kind === 'media' && (host.querySelector(mediaSelector) || cardHost(host))) return;
    const frame = host.querySelector(':scope > .np-lace-frame');
    if (frame) return;
    host.classList.add('np-framed', `np-${kind}`);
    const overlay = document.createElement('span');
    overlay.className = 'np-lace-frame';
    overlay.setAttribute('aria-hidden','true');
    host.append(overlay);
  }
  function decorate(scope) {
    if (!(scope instanceof Element || scope instanceof Document)) return;
    if (scope instanceof Element && scope.closest('.np-lace-frame')) return;
    const candidates = [...scope.querySelectorAll(selector)];
    if (scope instanceof Element && scope.matches(selector)) candidates.unshift(scope);
    for (const el of candidates) decorateCard(el);
    for (const el of candidates) {
      if (el.matches(commentSelector)) frameHost(el,'comment');
      else if (el.matches(playerSelector)) frameHost(el,'player');
      else if (el.matches(mediaSelector)) frameHost(el,'media');
      else if (el.matches(shortsImages) && !el.closest('.np-media')) {
        // Some Shorts versions expose only yt-image. Its title is a separate link.
        const host=el.closest('yt-image') || el.parentElement;
        if (host && !host.querySelector('h3, .shortsLockupViewModelHostMetadata, .yt-lockup-metadata-view-model')) frameHost(host,'media');
      }
    }
  }
  function apply(value) {
    enabled = value !== false;
    root.toggleAttribute('data-napolitano',enabled);
    if (enabled) decorate(document);
  }
  apply(true);
  chrome.storage.local.get({enabled:true}, result => apply(result.enabled));
  chrome.storage.onChanged.addListener((changes,area) => {
    if (area === 'local' && changes.enabled) apply(changes.enabled.newValue);
  });
  const pending = new Set();
  let scheduled = false;
  function schedule() {
    if (!pending.size || scheduled) return;
    scheduled=true;
    requestAnimationFrame(() => {
      scheduled=false;
      if (enabled) for (const node of pending) if (node.isConnected) {
        decorate(node);
        const host=node.parentElement?.closest(selector);
        if (host) decorate(host);
      }
      pending.clear();
    });
  }
  new MutationObserver(records => {
    if (!enabled) return;
    for (const record of records) {
      if (record.target instanceof Element && record.target.closest('.np-lace-frame')) continue;
      for (const node of record.addedNodes) {
        if (node.nodeType===1 && !node.classList.contains('np-lace-frame')) pending.add(node);
      }
      if ([...record.removedNodes].some(n => n.nodeType===1 && n.classList.contains('np-lace-frame'))) pending.add(record.target);
    }
    schedule();
  }).observe(root,{childList:true,subtree:true});
  document.addEventListener('yt-navigate-finish', () => {if (enabled) decorate(document);});
})();
