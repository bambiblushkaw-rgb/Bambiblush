'use strict';
const toggle = document.getElementById('enabled');
const status = document.getElementById('status');
const render = enabled => { toggle.checked = enabled; status.textContent = enabled ? 'Tema napolitano activado 🎀' : 'Tema desactivado'; };
chrome.storage.local.get({enabled:true}, data => render(data.enabled !== false));
toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  chrome.storage.local.set({enabled}, () => {
    if (chrome.runtime.lastError) { status.textContent = 'No se pudo guardar. Inténtalo otra vez.'; return; }
    render(enabled);
  });
});
