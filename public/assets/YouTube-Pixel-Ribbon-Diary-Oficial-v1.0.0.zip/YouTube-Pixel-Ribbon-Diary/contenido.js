(() => {
'use strict';
if(window.__pixelRibbonDiaryLoaded)return;window.__pixelRibbonDiaryLoaded=true;
const root=document.documentElement;
const files={heart:'heart-gloss.svg',bow:'bow-gloss.svg',wallpaper:'wallpaper.svg',titlebar:'titlebar.svg',windows:'window-buttons.svg',star:'14_estrella_pixel.png',folder:'02_carpeta_corazon.png',ribbon:'03_lazo_pixel.png',cd:'04_cd_retro.png',disk:'05_disquete.png',window:'06_ventanita.png',cursor:'07_cursor_pixel.png',bunny:'08_conejito.png',cat:'09_gatita.png',sparkle:'10_destello.png',cloud:'11_nube_pixel.png',message:'12_mensaje_retro.png',playSticker:'13_boton_play.png',originalStar:'01_corazon_pixel.png'};
const url=f=>`url("${chrome.runtime.getURL('assets/'+f)}")`;
for(const [key,file] of Object.entries(files))root.style.setProperty('--prd-'+key,url(file));
for(const name of ['play','pause','replay','next','previous','volume','mute','settings','fullscreen','exit-fullscreen','theater','mini','captions','share','home','comment','folder','like','dislike','heart','sort','remix'])root.style.setProperty('--prd-icon-'+name,url('control-'+name+'.svg'));
let enabled=false,pending=false,timer=0,header=null,headerArt=null,headerKey='',headerResize=null;
const videos=new WeakSet(),resizes=new WeakSet();
const mediaSelector='ytd-thumbnail #thumbnail,yt-thumbnail-view-model,.ytThumbnailViewModelHost,.shortsLockupViewModelHostThumbnailContainer,.shortsLockupViewModelHostThumbnail,ytd-reel-item-renderer #thumbnail';
function node(tag,cls){const el=document.createElement(tag);el.className=cls;el.setAttribute('aria-hidden','true');return el;}
function frame(host,kind){
 if(host.querySelector(':scope > .prd-frame'))return;
 host.classList.add('prd-media','prd-'+kind);
 const f=node('span','prd-frame');
 f.append(node('span','prd-titlebar'),node('i','prd-window-buttons'));
 for(const type of ['bow','heart','bunny','sparkle'])f.append(node('i','prd-ornament prd-ornament-'+type));
 host.append(f);
 if(typeof ResizeObserver!=='undefined'&&!resizes.has(host)){
 resizes.add(host);new ResizeObserver(entries=>{for(const {target,contentRect} of entries){const value=contentRect.width<260?'tiny':contentRect.width<480?'compact':'full';if(target.dataset.prdSize!==value)target.dataset.prdSize=value;}}).observe(host);
 }
}
function thumbnails(){
 for(const el of document.querySelectorAll(mediaSelector)){
  if(el.closest('.html5-video-player,.prd-frame'))continue;
  if(el.parentElement?.closest(mediaSelector))continue;
  frame(el,el.closest('ytd-reel-item-renderer,ytm-shorts-lockup-view-model')||el.matches('[class*="shorts"]')?'short-thumb':'thumb');
 }
}
function skinIcon(button,kind){
 if(!button)return;
 const icon=button.querySelector('yt-icon,.ytIconWrapperHost');if(!icon)return;
 icon.classList.add('prd-icon');icon.style.setProperty('--prd-icon',`var(--prd-icon-${kind})`);
}
function categories(){
 const seen=new Set();
 for(const candidate of document.querySelectorAll('yt-chip-cloud-chip-renderer,.ytChipShapeChip')){
  const chip=candidate.closest('yt-chip-cloud-chip-renderer')||candidate;if(seen.has(chip))continue;seen.add(chip);
  chip.classList.add('prd-chip');
  const text=(chip.textContent||'').toLowerCase();
  const kind=/m[uú]sica|music|podcast/.test(text)?'cd':/juego|gam/.test(text)?'disk':/estudio|escritorio|study|desk/.test(text)?'folder':/tutorial|tecnolog/.test(text)?'window':/maquill|moda|belleza/.test(text)?'bow':'heart';
  chip.style.setProperty('--prd-chip-icon',`var(--prd-${kind})`);
  chip.style.setProperty('--prd-chip-color',['#f9cee4','#e9d7fa','#fbe2ef','#dfdaf7'][seen.size%4]);
 }
}
function guide(){
 for(const item of document.querySelectorAll('ytd-guide-entry-renderer,ytd-mini-guide-entry-renderer')){
  const a=item.querySelector('a');if(!a)continue;
  const href=a.getAttribute('href')||'';
  skinIcon(item,href==='/'?'home':href.includes('/shorts')?'play':href.includes('history')?'replay':href.includes('playlist')||href.includes('subscriptions')?'folder':'heart');
 }
 const footer=document.querySelector('ytd-guide-renderer #footer');
 if(footer&&!footer.querySelector('.prd-signature')){
  const plaque=node('div','prd-signature');const brand=document.createElement('strong');brand.textContent='BambiBlush';const name=document.createElement('span');name.textContent='Pixel Ribbon Diary';plaque.append(brand,name);footer.prepend(plaque);
 }
}
const controlMap=[['ytp-play-button','play'],['ytp-prev-button','previous'],['ytp-next-button','next'],['ytp-mute-button','volume'],['ytp-subtitles-button','captions'],['ytp-settings-button','settings'],['ytp-miniplayer-button','mini'],['ytp-size-button','theater'],['ytp-fullscreen-button','fullscreen']];
function playbackState(player,video){
 if(!enabled)return;
 const set=(selector,name)=>{const b=player.querySelector(selector);if(b)b.style.setProperty('--prd-control',`var(--prd-icon-${name})`);};
 set('.ytp-play-button',video.ended?'replay':video.paused?'play':'pause');
 set('.ytp-mute-button',video.muted||video.volume===0?'mute':'volume');
 set('.ytp-fullscreen-button',document.fullscreenElement?'exit-fullscreen':'fullscreen');
 if(player.closest('ytd-reel-video-renderer')){
  const valid=Number.isFinite(video.duration)&&video.duration>0;
  for(const bar of player.closest('ytd-reel-video-renderer').querySelectorAll('.ytPlayerProgressBarHost,.ytProgressBarLineHost')){
   if(bar.parentElement?.closest('.ytPlayerProgressBarHost,.ytProgressBarLineHost'))continue;
   bar.classList.add('prd-short-timeline');bar.toggleAttribute('data-prd-determinate',valid);
   bar.style.setProperty('--prd-progress',`${valid?Math.min(100,Math.max(0,video.currentTime/video.duration*100)):0}%`);
  }
 }
}
function players(){
 for(const player of document.querySelectorAll('ytd-watch-flexy #movie_player,ytd-reel-video-renderer .html5-video-player')){
  frame(player,'player');
  for(const [cls,name] of controlMap){const button=player.querySelector('.'+cls);if(button){button.classList.add('prd-control');if(!button.style.getPropertyValue('--prd-control'))button.style.setProperty('--prd-control',`var(--prd-icon-${name})`);}}
  const video=player.querySelector('video');if(!video)continue;
  if(!videos.has(video)){
   videos.add(video);for(const event of ['play','pause','ended','volumechange','loadedmetadata','timeupdate','seeking','seeked','durationchange','emptied'])video.addEventListener(event,()=>playbackState(player,video),{passive:true});
  }
  playbackState(player,video);
 }
}
function comments(){
 for(const area of document.querySelectorAll('ytd-comments,ytd-comments-panel-renderer')){
  area.classList.add('prd-comments');
  for(const comment of area.querySelectorAll('ytd-comment-view-model,ytd-comment-renderer')){
   if(comment.parentElement?.closest('ytd-comment-view-model,ytd-comment-renderer'))continue;
   comment.classList.add('prd-comment-card');
   skinIcon(comment.querySelector('#like-button'),'heart');skinIcon(comment.querySelector('#dislike-button'),'dislike');
  }
  skinIcon(area.querySelector('#sort-menu'),'sort');
 }
 for(const short of document.querySelectorAll('ytd-reel-video-renderer')){
  for(const [id,kind] of [['like-button','heart'],['dislike-button','dislike'],['comments-button','comment'],['share-button','share'],['remix-button','remix']])skinIcon(short.querySelector('#'+id),kind);
  for(const b of short.querySelectorAll('#actions button')){
   const label=b.getAttribute('aria-label')||'';
   const kind=/dislike|no me gusta/i.test(label)?'dislike':/like|me gusta/i.test(label)?'heart':/comentario|comment/i.test(label)?'comment':/share|compartir/i.test(label)?'share':/remix/i.test(label)?'remix':null;if(kind)skinIcon(b,kind);
  }
 }
}
function headerDecoration(){
 const host=document.querySelector('ytd-masthead');if(!host)return;
 if(header!==host){
  headerResize?.disconnect();header=host;headerKey='';headerArt=host.querySelector(':scope > .prd-header-art');
  if(!headerArt){headerArt=node('span','prd-header-art');host.append(headerArt);}
  if(typeof ResizeObserver!=='undefined'){headerResize=new ResizeObserver(schedule);headerResize.observe(host);for(const el of host.querySelectorAll('#start,#center,#end'))headerResize.observe(el);}
 }
 const box=host.getBoundingClientRect();if(box.width<=0)return;
 const occupied=Array.from(host.querySelectorAll('#guide-button,#logo,yt-searchbox,ytd-searchbox,#voice-search-button,#end,button,input,a,[role="button"]'),el=>el.getBoundingClientRect())
  .filter(r=>r.width>0&&r.height>0).map(r=>[Math.max(box.left,r.left-6),Math.min(box.right,r.right+6)]).filter(r=>r[1]>r[0]).sort((a,b)=>a[0]-b[0]);
 let x=box.left+8;const gaps=[];
 for(const [l,r] of occupied){if(l>x)gaps.push([x,l]);x=Math.max(x,r);}if(x<box.right-8)gaps.push([x,box.right-8]);
 const list=[];const kinds=['bow','heart','cd','folder','sparkle','ribbon','cloud','disk','originalStar','window','cursor','message','playSticker','cat','bunny'];
 for(const [l,r] of gaps){const count=Math.min(6,Math.floor((r-l)/44));for(let i=0;i<count&&list.length<18;i++){const kind=kinds[list.length%kinds.length],size=kind==='bow'?38:kind==='heart'?27:30;list.push({kind,size,left:Math.round(l+(i+.5)*(r-l)/count-box.left-size/2),top:Math.max(14,Math.round((box.height-size)/2)+3)});}}
 const key=JSON.stringify(list);if(key===headerKey)return;headerKey=key;const fragment=document.createDocumentFragment();
 for(const item of list){const s=node('i','prd-header-sticker');s.style.backgroundImage=`var(--prd-${item.kind})`;s.style.left=item.left+'px';s.style.top=item.top+'px';s.style.width=s.style.height=item.size+'px';fragment.append(s);}
 headerArt.replaceChildren(fragment);
}
function run(){pending=false;timer=0;if(!enabled)return;root.dataset.prdPage=location.pathname.startsWith('/shorts')?'shorts':location.pathname==='/watch'?'watch':'browse';thumbnails();categories();guide();players();comments();headerDecoration();}
function schedule(){if(!enabled||pending)return;pending=true;timer=setTimeout(()=>requestAnimationFrame(run),75);}
function apply(value){enabled=value;root.classList.toggle('prd-on',value);if(!value&&timer){clearTimeout(timer);timer=0;pending=false;}schedule();}
chrome.storage.local.get({ribbonEnabled:true},d=>apply(d.ribbonEnabled!==false));
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.ribbonEnabled)apply(changes.ribbonEnabled.newValue!==false);});
new MutationObserver(records=>{if(records.some(r=>!r.target.closest?.('.prd-frame,.prd-header-art,.prd-signature')))schedule();}).observe(root,{childList:true,subtree:true});
for(const event of ['yt-navigate-finish','yt-page-data-updated','fullscreenchange'])document.addEventListener(event,schedule);
window.addEventListener('resize',schedule,{passive:true});
})();
