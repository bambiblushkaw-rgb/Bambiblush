/* Decorative masthead layer only. No modification to playback, categories or native events. */
(() => {
'use strict';
if(window.__sgHeaderFinish)return;window.__sgHeaderFinish=true;
const root=document.documentElement;
root.style.setProperty('--sg-header-pixel-rainbow',`url("${chrome.runtime.getURL('assets/header-rainbow-pixel.svg')}")`);
let masthead=null,layer=null,pending=false,signature='',resize=null,mutations=null;
const exclusions='#guide-button,#logo,yt-searchbox,ytd-searchbox,#search-form,#search-icon-legacy,#voice-search-button,#end,button,input,a,[role="button"],[contenteditable="true"]';
function planDecorations(bounds,rects){
 const left=bounds.left,right=bounds.right;
 const spans=rects.filter(r=>r.width>0&&r.height>0&&r.bottom>bounds.top&&r.top<bounds.bottom)
  .map(r=>[Math.max(left,r.left-10),Math.min(right,r.right+10)]).filter(r=>r[1]>r[0]).sort((a,b)=>a[0]-b[0]);
 const gaps=[];let cursor=left+8;
 for(const [a,b] of spans){if(a>cursor)gaps.push([cursor,a]);cursor=Math.max(cursor,b);}
 if(cursor<right-8)gaps.push([cursor,right-8]);
 const kinds=[['star',18,18],['cloud',26,24],['star',16,16],['rainbow',38,21]];
 const result=[];
 for(const [a,b] of gaps){
  // Leave controls a further 5px buffer; max 14 small decorations across the entire bar.
  const n=Math.min(5,Math.floor((b-a)/55));
  for(let j=0;j<n&&result.length<14;j++){
   const [kind,w,h]=kinds[result.length%kinds.length];
   const x=a+(j+.5)*(b-a)/n-w/2;
   if(x<a+5||x+w>b-5)continue;
   result.push({kind,w,h,x:Math.round(x-left),y:Math.max(3,Math.round((bounds.height-h)/2)+(result.length%2?3:-3))});
  }
 }
 return result;
}
function paint(){
 pending=false;
 const next=document.querySelector('ytd-masthead');if(!next)return;
 if(next!==masthead){
  resize?.disconnect();mutations?.disconnect();masthead=next;signature='';
  layer=masthead.querySelector(':scope > .sg-header-pixels');
  if(!layer){layer=document.createElement('span');layer.className='sg-header-pixels';layer.setAttribute('aria-hidden','true');masthead.append(layer);}
  if(typeof ResizeObserver!=='undefined'){
   resize=new ResizeObserver(schedule);resize.observe(masthead);
   for(const el of masthead.querySelectorAll('#container,#start,#center,#end,yt-searchbox,ytd-searchbox'))resize.observe(el);
  }
  mutations=new MutationObserver(records=>{if(records.some(r=>!layer.contains(r.target)))schedule();});
  mutations.observe(masthead,{childList:true,subtree:true});
 }
 const bounds=masthead.getBoundingClientRect();if(bounds.width<=0||bounds.height<=0)return;
 const rects=Array.from(masthead.querySelectorAll(exclusions),el=>el.getBoundingClientRect());
 const items=planDecorations(bounds,rects),key=JSON.stringify(items);
 if(signature===key)return;signature=key;
 const fragment=document.createDocumentFragment();
 items.forEach((item,i)=>{
  const el=document.createElement('i');el.className='sg-header-'+item.kind;
  el.style.left=item.x+'px';el.style.top=item.y+'px';el.style.width=item.w+'px';el.style.height=item.h+'px';
  el.style.setProperty('--sg-delay',(-i*.67)+'s');
  if(item.kind==='star')el.style.filter=`hue-rotate(${[0,285,165,225][i%4]}deg)`;
  fragment.append(el);
 });
 layer.replaceChildren(fragment);
}
function schedule(){if(!pending){pending=true;requestAnimationFrame(paint);}}
new MutationObserver(()=>{if(!masthead?.isConnected)schedule();}).observe(root,{childList:true,subtree:true});
window.addEventListener('resize',schedule,{passive:true});
document.addEventListener('yt-navigate-finish',schedule);
document.fonts?.ready.then(schedule);
schedule();
})();
