(() => {
'use strict';
if (window.__starGoLoaded) return;
window.__starGoLoaded=true;
const root=document.documentElement;
for(const [key,file] of Object.entries({star:'star.svg',cloud:'cloud.svg',sparkle:'sparkle.svg',header:'header.svg',garland:'06-Guirnalda-estrellas.png',rainbow:'02-Arcoiris.png',friends:'01-Estrellas-nube.png'})) root.style.setProperty('--sg-'+key,`url("${chrome.runtime.getURL('assets/'+file)}")`);
let enabled=true, pending=false;
function route(){
 const path=location.pathname;
 root.dataset.sgPage=path==='/watch'?'watch':path.startsWith('/shorts')?'shorts':path==='/'?'home':'other';
}
function decorate(){
 pending=false;route();if(!enabled)return;
 // Add only decorative surfaces. No video, click, keyboard or timeline handlers are replaced.
 for(const btn of document.querySelectorAll('.ytp-left-controls > button,.ytp-right-controls > button,.ytp-volume-area > button')){
   if(btn.classList.contains('ytp-play-button')||btn.classList.contains('ytp-mute-button'))btn.dataset.sgShape='cloud';
   else btn.dataset.sgShape='star';
 }
 for(const bar of document.querySelectorAll('ytd-feed-filter-chip-bar-renderer,yt-chip-cloud-renderer')){
 let i=0;for(const chip of bar.querySelectorAll('yt-chip-cloud-chip-renderer')){
 const c=['#fff0af','#fbe0ed','#e8ddfa','#def0ed','#e0eefa'][i++%5];
 if(chip.style.getPropertyValue('--sg-chip')!==c)chip.style.setProperty('--sg-chip',c);
 }
 }
}
function schedule(){if(!pending){pending=true;requestAnimationFrame(decorate);}}
function apply(v){enabled=v;root.classList.toggle('sg-on',v);schedule();}
chrome.storage.local.get({starGoEnabled:true},d=>apply(d.starGoEnabled!==false));
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.starGoEnabled)apply(changes.starGoEnabled.newValue!==false);});
new MutationObserver(schedule).observe(root,{childList:true,subtree:true});
document.addEventListener('yt-navigate-finish',schedule);document.addEventListener('yt-page-data-updated',schedule);
route();
})();