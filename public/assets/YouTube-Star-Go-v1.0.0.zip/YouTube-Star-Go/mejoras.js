/* Star Go 0.2: additive decorations. Never modify or bind normal player controls. */
(() => {
'use strict';
if(window.__starGoExtras)return;window.__starGoExtras=true;
const root=document.documentElement;
for(const file of ['chip-cloud','bubble','share','remix','sort'])root.style.setProperty('--sg-'+file,`url("${chrome.runtime.getURL('assets/'+file+'.svg')}")`);
const THUMBS='ytd-thumbnail #thumbnail,yt-thumbnail-view-model,.ytThumbnailViewModelHost';
const COMMENTS='ytd-comments,ytd-comments-panel-renderer';
const SHORTS='ytd-reel-video-renderer';
const progressSelector='.ytPlayerProgressBarHost,.ytProgressBarLineHost,yt-progress-bar,.ytp-progress-bar-container';
let pending=false,enabled=false;
const bound=new WeakSet();
function icon(button,kind){
 if(!button||button.closest('#movie_player')&&!button.closest(SHORTS))return;
 const host=button.querySelector('yt-icon')||button.querySelector('.ytIconWrapperHost');
 if(!host)return;
 if(host.dataset.sgIcon!==kind)host.dataset.sgIcon=kind;
 const pressed=button.getAttribute('aria-pressed')==='true'||button.getAttribute('aria-label')?.match(/(quitar|remove|unlike)/i);
 host.classList.toggle('sg-selected',!!pressed);
}
function comments(){
 for(const area of document.querySelectorAll(COMMENTS)){
 for(const comment of area.querySelectorAll('ytd-comment-view-model,ytd-comment-renderer')){
 icon(comment.querySelector('#like-button button,#like-button [role="button"]'),'star');
 icon(comment.querySelector('#dislike-button button,#dislike-button [role="button"]'),'cloud');
 }
 icon(area.querySelector('#sort-menu button,#sort-menu [role="button"],#sort-menu yt-dropdown-menu'),'sort');
 }
}
function shortIcons(short){
 const pairs=[['#like-button','star'],['#dislike-button','cloud'],['#comments-button','bubble'],['#share-button','share'],['#remix-button','remix']];
 for(const [id,kind] of pairs)icon(short.querySelector(id+' button,'+id+' [role="button"]'),kind);
 // Current Shorts layouts sometimes omit IDs. Read localized accessible names, never visible counts.
 for(const b of short.querySelectorAll('#actions button,#actions [role="button"],.ReelPlayerOverlayRendererActionBar button')){
 const label=b.getAttribute('aria-label')||'';
 const kind=/no me gusta|dislike/i.test(label)?'cloud':/me gusta|like/i.test(label)?'star':/comentario|comment/i.test(label)?'bubble':/compartir|share/i.test(label)?'share':/remix/i.test(label)?'remix':null;
 if(kind)icon(b,kind);
 }
}
function updateProgress(short,video){
 if(!enabled)return;
 // Live/unknown durations have no determinate progress. Do not invent one.
 const duration=video.duration;
 const valid=Number.isFinite(duration)&&duration>0;
 const ratio=valid?Math.max(0,Math.min(1,video.currentTime/duration)):0;
 for(const bar of short.querySelectorAll(progressSelector)){
 // Choose outermost progress surface: prevents double stars on nested variants.
 if(bar.parentElement?.closest(progressSelector))continue;
 bar.classList.add('sg-short-progress');
 bar.toggleAttribute('data-sg-determinate',valid);
 bar.style.setProperty('--sg-progress',`${ratio*100}%`);
 }
}
function shorts(){
 for(const short of document.querySelectorAll(SHORTS)){
 shortIcons(short);
 const video=short.querySelector('video');if(!video)continue;
 if(!bound.has(video)){
 bound.add(video);
 const update=()=>updateProgress(short,video);
 for(const evt of ['timeupdate','seeking','seeked','loadedmetadata','durationchange','emptied','ended'])video.addEventListener(evt,update,{passive:true});
 }
 updateProgress(short,video);
 }
}
function thumbnails(){
 for(const thumb of document.querySelectorAll(THUMBS)){
 if(thumb.closest('.html5-video-player,ytd-reel-video-renderer')||thumb.querySelector('.sg-thumb-stars'))continue;
 // Prefer the outer thumbnail host; don't add nested decorations.
 const parent=thumb.parentElement?.closest(THUMBS);if(parent)continue;
 thumb.classList.add('sg-thumb-host');
 const overlay=document.createElement('span');overlay.className='sg-thumb-stars';overlay.setAttribute('aria-hidden','true');
 for(let i=0;i<4;i++){const s=document.createElement('i');s.className='sg-corner sg-corner-'+i;overlay.append(s);}
 thumb.append(overlay);
 }
}
function categories(){
 const seen=new Set();
 for(const node of document.querySelectorAll('yt-chip-cloud-chip-renderer,.ytChipShapeChip')){
 const host=node.closest('yt-chip-cloud-chip-renderer')||node;
 if(seen.has(host))continue;seen.add(host);
 host.classList.add('sg-category');
 const color=['#fbe0ed','#fff0af','#e0eefa','#e8ddfa','#def0ed'][(seen.size-1)%5];
 if(host.style.getPropertyValue('--sg-chip')!==color)host.style.setProperty('--sg-chip',color);
 }
}
function run(){pending=false;if(!enabled)return;comments();shorts();thumbnails();categories();}
function schedule(){if(pending||!enabled)return;pending=true;requestAnimationFrame(run);}
function apply(value){enabled=value;schedule();}
chrome.storage.local.get({starGoEnabled:true},d=>apply(d.starGoEnabled!==false));
chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.starGoEnabled)apply(c.starGoEnabled.newValue!==false);});
new MutationObserver(schedule).observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-pressed','aria-label']});
document.addEventListener('yt-navigate-finish',schedule);document.addEventListener('yt-page-data-updated',schedule);
})();
